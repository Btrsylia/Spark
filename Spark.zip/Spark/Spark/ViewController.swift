//
//  ViewController.swift
//  Spark
//
//  Created by STDC_50 on 04/08/2024.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var searchField: UITextField!


    override func viewDidLoad() {
        super.viewDidLoad()
        searchField.text = ""
        // Do any additional setup after loading the view.
    }
    
}


extension UIImageView {
     func outlineBox() {
        self.layoutIfNeeded()
        self.layer.borderColor = UIColor.systemYellow.cgColor
        self.layer.borderWidth = 10.0
        self.layer.cornerRadius = 0 // or you can remove this line
        self.clipsToBounds = true
    }
}


